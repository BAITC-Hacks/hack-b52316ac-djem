"""Akim city simulator."""
